# Prova

Privamo a vedere come va

![portafoglio_crypto.png](Prova%207d735/portafoglio_crypto.png)

## Mediamo